package com.virtusa.issuetracking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.virtusa.issuetracking.model.Ticket;
import com.virtusa.issuetracking.service.TicketService;

@Controller
@RequestMapping(value="/ticket")
public class TicketController {
	
	@Autowired
	private TicketService ticketService;
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addTeamPage() {
		ModelAndView modelAndView = new ModelAndView("add-ticket-form");
		modelAndView.addObject("team", new Ticket());
		return modelAndView;
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public ModelAndView addingTicket(@ModelAttribute Ticket ticket) {
		
		ModelAndView modelAndView = new ModelAndView("home");
		ticketService.addTicket(ticket);
		
		String message = "Ticket was successfully added.";
		modelAndView.addObject("message", message);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/list")
	public ModelAndView listOfTickets() {
		ModelAndView modelAndView = new ModelAndView("list-of-tickets");
		
		List<Ticket> tickets = ticketService.getTickets();
		modelAndView.addObject("tickets", tickets);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.GET)
	public ModelAndView editTicketPage(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("edit-ticket-form");
		Ticket ticket = ticketService.getTicket(id);
		modelAndView.addObject("ticket",ticket);
		return modelAndView;
	}
	
	@RequestMapping(value="/edit/{id}", method=RequestMethod.POST)
	public ModelAndView edditingTicket(@ModelAttribute Ticket ticket, @PathVariable Integer id) {
		
		ModelAndView modelAndView = new ModelAndView("home");
		
		ticketService.updateTicket(ticket);
		
		String message = "Ticket was successfully edited.";
		modelAndView.addObject("message", message);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/delete/{id}", method=RequestMethod.GET)
	public ModelAndView deleteTicket(@PathVariable Integer id) {
		ModelAndView modelAndView = new ModelAndView("home");
		ticketService.deleteTicket(id);
		String message = "Team was successfully deleted.";
		modelAndView.addObject("message", message);
		return modelAndView;
	}

}
