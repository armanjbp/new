package com.virtusa.issuetracking.dao;

import com.virtusa.issuetracking.model.Login;
import com.virtusa.issuetracking.model.User;

public interface UserDao {

  int register(User user);

  User validateUser(Login login);
}
