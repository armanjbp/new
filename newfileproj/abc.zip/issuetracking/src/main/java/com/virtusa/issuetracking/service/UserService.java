package com.virtusa.issuetracking.service;

import com.virtusa.issuetracking.model.Login;
import com.virtusa.issuetracking.model.User;

public interface UserService {

  int register(User user);

  User validateUser(Login login);
}
