package com.virtusa.issuetracking.dao;

import java.util.List;

import com.virtusa.issuetracking.model.Ticket;

public interface TicketDAO {

	public void addTicket(Ticket ticket);
	public void updateTicket(Ticket ticket);
	public Ticket getTicket(int id);
	public void deleteTicket(int id);
	public List<Ticket> getTickets();

}
