package com.virtusa.issuetracking.service;

import java.util.List;

import com.virtusa.issuetracking.model.Ticket;

public interface TicketService {

	public void addTicket(Ticket ticket);
	public void updateTicket(Ticket ticket);
	public Ticket getTicket(int id);
	public void deleteTicket(int id);
	public List<Ticket> getTickets();

}
