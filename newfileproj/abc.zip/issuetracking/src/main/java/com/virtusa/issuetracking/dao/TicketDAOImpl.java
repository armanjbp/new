package com.virtusa.issuetracking.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.issuetracking.model.Ticket;

@Repository
public class TicketDAOImpl implements TicketDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public void addTicket(Ticket ticket) {
		getCurrentSession().save(ticket);
		
	}

	public void updateTicket(Ticket ticket) {
		Ticket ticketToUpdate = getTicket(ticket.getId());
		ticketToUpdate.setName(ticket.getName());
		ticketToUpdate.setResult(ticket.getResult());
		//ticketToUpdate.setType(ticket.getType());
		getCurrentSession().update(ticketToUpdate);
		
	}

	public Ticket getTicket(int id) {
		Ticket ticket = (Ticket) getCurrentSession().get(Ticket.class, id);
		return ticket;
	}

	public void deleteTicket(int id) {
		Ticket ticket = getTicket(id);
		if (ticket != null)
			getCurrentSession().delete(ticket);		
	}

	@SuppressWarnings("unchecked")
	public List<Ticket> getTickets() {
		return getCurrentSession().createQuery("from Ticket").list();
	}

}
